package org.nomfamille.exo1;

public class Imperatif {


   /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/


    public static String aZ(int hauteur){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }

    public static Integer bPremiersEntiers(int max){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }

    public static String[] cCopie(int longueur, String depart){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }


}
