package org.nomfamille.exo1;
import org.junit.Assert;
import org.junit.Test;

public class TestImperatif
{
    @Test(timeout = 1000)
    public void testA(){
        String ls = "\n";
        String taille5 =
                        "ZZZZZ"+ls+
                        "   Z"+ls+
                        " Z"+ls+
                        "Z"+ls+
                        "ZZZZZ"+ls;
        System.out.println("Attendu \n" + taille5);
        System.out.println("Obtenu \n"  + Imperatif.aZ(5));
        Assert.assertEquals("Les deux String devraient être égales", taille5, Imperatif.aZ(5));
        String taille7 =
                        "ZZZZZZZ"+ls+
                        "     Z"+ls+
                        "    Z"+ls+
                        "   Z"+ls+
                        "  Z"+ls+
                        " Z"+ls+
                        "ZZZZZZZ"+ls;
        System.out.println("Attendu \n" + taille7);
		System.out.println("Obtenu \n" + Imperatif.aZ(7));
        Assert.assertEquals("Les deux String devraient être égales", taille7, Imperatif.aZ(7));
    }

    @Test(timeout = 1000)
    public void testB(){
        Assert.assertEquals(6, Imperatif.bPremiersEntiers(3).intValue());
        Assert.assertEquals(15, Imperatif.bPremiersEntiers(5).intValue());
        Assert.assertEquals(55, Imperatif.bPremiersEntiers(10).intValue());
        Assert.assertEquals(1275, Imperatif.bPremiersEntiers(50).intValue());
    }

    @Test(timeout = 1000)
    public void testB1(){
        Assert.assertNull(Imperatif.bPremiersEntiers(-10));
        Assert.assertNull(Imperatif.bPremiersEntiers(0));
    }

    @Test(timeout = 1000)
    public void testC(){
        Assert.assertArrayEquals(new String[]{"abc","abcabc","abcabcabc","abcabcabcabc"}, Imperatif.cCopie(4, "abc"));
        Assert.assertArrayEquals(new String[]{"a","aa"}, Imperatif.cCopie(2, "a"));
        Assert.assertArrayEquals(new String[]{"1b-"}, Imperatif.cCopie(1, "1b-"));
        Assert.assertArrayEquals(new String[]{}, Imperatif.cCopie(0, "1"));
    }

    @Test(timeout = 1000 )
    public void testC1(){
        Assert.assertNull(Imperatif.cCopie(-3, "123"));
    }

    @Test(timeout = 1000)
    public void testC2(){
        Assert.assertNull(Imperatif.cCopie(3, ""));
    }
}
