package intra.externe;

import java.io.IOException;

public class LibExterne {
    public static void main( String[] args ) throws IOException {

        // TODO ton code ici

    }
}
