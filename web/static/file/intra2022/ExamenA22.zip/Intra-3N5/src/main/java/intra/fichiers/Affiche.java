package intra.fichiers;

public class Affiche
{
    public static void main( String[] args )
    {

        // TODO ton code ici

    }
}