package intra.fichiers;

import java.io.IOException;

public class Ecrit
{
    public static void main( String[] args ) throws IOException {

        // TODO ton code ici

    }
}
