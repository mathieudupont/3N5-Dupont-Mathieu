package intra.listes;

import java.util.*;

public class ExoListe
{
    public static List<Integer> joursParMois(int n) throws IllegalArgumentException {

        // TODO ton code ici, et supprime la ligne ci-dessous :
        throw new UnsupportedOperationException();

    }

    public static List<Double> tri(List<Double> liste){

        // TODO ton code ici, et supprime la ligne ci-dessous :
        throw new UnsupportedOperationException();

    }
}
