package intra.programmation;

public class ExoProgrammation {

    public static int compteChiffre(int chiffre, int nombre) throws IllegalArgumentException {

        // TODO ton code ici, et supprime la ligne ci-dessous :
        throw new UnsupportedOperationException();

    }

}
